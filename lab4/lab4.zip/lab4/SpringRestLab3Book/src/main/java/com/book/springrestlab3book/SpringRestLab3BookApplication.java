package com.book.springrestlab3book;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestLab3BookApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestLab3BookApplication.class, args);
	}

}
