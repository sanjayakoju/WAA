package com.bank.springrestlab3bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestLab3BankApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringRestLab3BankApplication.class, args);
    }

}
