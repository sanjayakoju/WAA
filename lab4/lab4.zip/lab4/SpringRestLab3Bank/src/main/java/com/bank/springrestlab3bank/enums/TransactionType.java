package com.bank.springrestlab3bank.enums;

public enum TransactionType {
    DEPOSIT, WITHDRAW
}
