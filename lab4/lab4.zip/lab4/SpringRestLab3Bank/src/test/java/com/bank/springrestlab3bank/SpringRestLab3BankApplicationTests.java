package com.bank.springrestlab3bank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestLab3BankApplicationTests {

    @Test
    void contextLoads() {
    }

}
