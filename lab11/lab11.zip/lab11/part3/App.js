import './App.css';
import {TodoDone} from "./pages/TodoDone";

function App() {
  return (
    <div className="App">
      <TodoDone/>
    </div>
  );
}

export default App;
